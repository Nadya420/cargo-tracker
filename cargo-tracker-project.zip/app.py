from flask import Flask, request, jsonify, session, send_from_directory
from pathlib import Path
import json
from functools import wraps

app = Flask(__name__, static_folder="static")
app.secret_key = "change-this-secret-key-before-deployment"
DATA_FILE = Path("cargo_data.json")

def load_cargo():
    if DATA_FILE.exists():
        try:
            return json.loads(DATA_FILE.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return []
    return [
        {
            "id": "CT-1001",
            "name": "Электронное оборудование",
            "origin": "Китай",
            "destination": "Россия",
            "status": "В пути",
            "updated": "2026-11-20",
            "history": ["Груз зарегистрирован", "Отправлен со склада"]
        }
    ]

def save_cargo(items):
    DATA_FILE.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            return jsonify({"error": "Требуется авторизация"}), 401
        return fn(*args, **kwargs)
    return wrapper

@app.get("/")
def home():
    return send_from_directory(".", "index.html")

@app.get("/<path:path>")
def static_files(path):
    if path.startswith("static/"):
        return send_from_directory(".", path)
    return send_from_directory(".", path)

@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    # Учебная демонстрационная авторизация. Для реального использования нужен безопасный пароль и база пользователей.
    if data.get("username") == "admin" and data.get("password") == "cargo123":
        session["logged_in"] = True
        return jsonify({"ok": True})
    return jsonify({"error": "Неверный логин или пароль"}), 401

@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify({"ok": True})

@app.get("/api/cargo")
@login_required
def get_cargo():
    return jsonify(load_cargo())

@app.post("/api/cargo")
@login_required
def add_cargo():
    data = request.get_json(silent=True) or {}
    required = ["id", "name", "origin", "destination", "status"]
    if any(not str(data.get(k, "")).strip() for k in required):
        return jsonify({"error": "Заполните все обязательные поля"}), 400
    items = load_cargo()
    if any(item["id"].lower() == data["id"].lower() for item in items):
        return jsonify({"error": "Груз с таким номером уже существует"}), 409
    data["updated"] = data.get("updated") or "2026-11-20"
    data["history"] = ["Груз зарегистрирован"]
    items.insert(0, data)
    save_cargo(items)
    return jsonify(data), 201

@app.patch("/api/cargo/<cargo_id>")
@login_required
def update_cargo(cargo_id):
    data = request.get_json(silent=True) or {}
    items = load_cargo()
    for item in items:
        if item["id"] == cargo_id:
            if data.get("status") and data["status"] != item["status"]:
                item["history"].append(f"Статус изменён: {item['status']} → {data['status']}")
                item["status"] = data["status"]
            if data.get("updated"):
                item["updated"] = data["updated"]
            save_cargo(items)
            return jsonify(item)
    return jsonify({"error": "Груз не найден"}), 404

@app.delete("/api/cargo/<cargo_id>")
@login_required
def delete_cargo(cargo_id):
    items = load_cargo()
    new_items = [item for item in items if item["id"] != cargo_id]
    if len(new_items) == len(items):
        return jsonify({"error": "Груз не найден"}), 404
    save_cargo(new_items)
    return jsonify({"ok": True})

@app.get("/api/export")
@login_required
def export_cargo():
    return jsonify(load_cargo())

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
